x = 0
y = 0

charDead = False

left = True

isShot = False
bulletX = 0
bulletY = 0
bulletused = False

gameLive = False

lifes = 3

points = 0

reset = False

takeLife = False
gameOver = True
increaseLevel = False